﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SplitTheBills;

namespace SplitTheBillUnitTests
{
    [TestClass]
    public class SplitTheBillTest
    {
        [TestMethod]
        public void SplitTheBillMain_FileNotFound_ThroghFileNotFoundExitCode()
        {           
            //Throw file not found. Exit code is 1
           // Assert.AreEqual(bill.SplitTheBill());           
        }
    }
}
